"""
Interface 2/3 backend: optimise a lexoid .tex and report what changed.

    python -m texopt.cli optimise IN.tex -o OUT.tex --start-page 76 \
        --registry fields.json --report report.json
    python -m texopt.cli verify OUT.tex OUT.pdf --registry fields.json
"""

from __future__ import annotations

import argparse
import difflib
import json
import sys
from pathlib import Path

from . import opaque, preamble
from .fields import DetectorConfig, annotate_fields, write_registry
from .llm import HeuristicBatchNamer, LLMBatchNamer
from .tex_tables import TableStat, transform_tex


def cmd_audit(a: argparse.Namespace) -> int:
    print(opaque.audit(Path(a.input).read_text("utf-8")))
    return 0


def _risks(src: str) -> list:
    return [{"line": r.line, "env": r.env, "construct": r.construct,
             "note": r.note, "severity": r.severity}
            for r in opaque.format_guard(src)]


def cmd_probe(a: argparse.Namespace) -> int:
    """Emit an instrumented copy. Compile it ONCE, then pass its .log to `optimise`."""
    src = Path(a.input).read_text("utf-8")
    inst, tables = opaque.instrument(src)
    Path(a.output).write_text(inst, "utf-8")
    print(f"wrote {a.output} with probes for {len(tables)} opaque table(s).")
    print("next: xelatex -interaction=nonstopmode "
          f"{Path(a.output).name}   # then: optimise --widths-log <that>.log")
    return 0


def cmd_optimise(a: argparse.Namespace) -> int:
    src = Path(a.input).read_text("utf-8")

    conv_report = None
    format_risks = _risks(src)
    tables = opaque.find_opaque(src)
    if tables:
        widths = {}
        if a.widths_log:
            widths = opaque.parse_widths(
                Path(a.widths_log).read_text("utf-8", errors="replace"))

        # Which tables cannot be solved in closed form? Only those need a compile.
        need_probe = [t for t in tables
                      if opaque.static_widths(t) is None
                      and not all((t.tid, c) in widths for c in t.flex_cols)]
        if need_probe and a.probe:
            print(f"{len(need_probe)} table(s) need measuring; running {a.probe_engine} "
                  f"probe compile...", file=sys.stderr)
            measured, log = opaque.run_probe(src, Path(a.probe_dir or ".texopt-probe"),
                                             engine=a.probe_engine)
            if not measured:
                print("  probe produced no widths -- check "
                      f"{a.probe_dir or '.texopt-probe'}/texopt_probe.log", file=sys.stderr)
            widths.update(measured)

        try:
            src, conv_report = opaque.convert(src, widths, strict=not a.allow_opaque)
        except opaque.UnconvertibleTable as e:
            print(f"ERROR: {e}", file=sys.stderr)
            return 3
    remaining = opaque.find_opaque(src)

    stats: list[TableStat] = []
    step1 = transform_tex(src, anchor=not a.no_anchor, stats=stats)

    cfg = DetectorConfig()
    if a.force_columns:
        cfg.force_columns = [int(c) for c in a.force_columns.split(",") if c.strip()]
    if a.detect_pattern:
        cfg.patterns = a.detect_pattern

    # ORDER MATTERS: the preamble must be injected BEFORE field annotation, otherwise
    # every tex_line in the registry is off by the size of the macro block and the
    # SyncTeX verification silently checks the wrong lines.
    step1b = preamble.inject(step1) if not a.no_preamble else step1
    if a.no_llm:
        namer = HeuristicBatchNamer()
    else:
        namer = LLMBatchNamer(Path(a.name_cache), model=a.llm_model)
        if not namer.api_key:
            print("ANTHROPIC_API_KEY not set -- field names will be positional "
                  "(r01c02), not meaningful. Set the key or pass --no-llm to silence.",
                  file=sys.stderr)
    out, records, name_stats = annotate_fields(step1b, start_page=a.start_page,
                                               detector=cfg, namer=namer)

    Path(a.output).write_text(out, "utf-8")
    if a.registry:
        write_registry(records, Path(a.registry))

    report = {
        "input": str(a.input), "output": str(a.output),
        "tables": len(stats),
        "cells": sum(s.cells for s in stats),
        "rows": sum(s.rows for s in stats),
        "fields": len(records),
        "lines_before": src.count("\n") + 1,
        "lines_after": out.count("\n") + 1,
        "field_ids": [r.field_id for r in records],
        "naming": name_stats,
        "naming_fallbacks": sorted({r.table for r in records
                                    if r.name_source == "heuristic"}),
        "opaque_converted": conv_report.converted if conv_report else [],
        "opaque_width_source": conv_report.by_source if conv_report else {},
        "opaque_detail": conv_report.details if conv_report else [],
        "format_risks": format_risks,
        "opaque_skipped": conv_report.skipped if conv_report else [],
        "opaque_remaining": [{"line": t.line, "env": t.env, "notes": t.notes}
                             for t in remaining],
    }
    fb = report["naming_fallbacks"]
    if fb and not a.no_llm:
        print(f"NAMING: {len(fb)} table(s) fell back to positional names "
              f"(model unavailable or response rejected): {fb[:5]}", file=sys.stderr)
    warns = [r for r in format_risks if r["severity"] == "warn"]
    if warns:
        print(f"FORMAT RISK: {len(warns)} construct(s) inside converted tables behave "
              f"differently under a single-pass body. See report.format_risks; "
              f"confirm with `verify --check-geometry`.", file=sys.stderr)
        for r in warns[:8]:
            print(f"  line {r['line']}: {r['construct']} -- {r['note']}", file=sys.stderr)
    if remaining:
        print(f"WARNING: {len(remaining)} table(s) still in a SyncTeX-opaque "
              f"environment; their cells cannot be located precisely. "
              f"Run `texopt probe` + compile + `--widths-log` to convert them.",
              file=sys.stderr)
    if a.report:
        Path(a.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), "utf-8")
    if a.diff:
        Path(a.diff).write_text("\n".join(difflib.unified_diff(
            src.splitlines(), out.splitlines(),
            fromfile="before", tofile="after", lineterm="")), "utf-8")

    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


def cmd_verify(a: argparse.Namespace) -> int:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from verify.checks import (content_regression, geometry_regression,
                           summarize, synctex_roundtrip)

    reg = json.loads(Path(a.registry).read_text("utf-8")) if a.registry else {"fields": []}
    lines = [f["tex_line"] for f in reg["fields"]] or list(range(1, 2))
    res = synctex_roundtrip(Path(a.tex), Path(a.pdf), lines)
    print(summarize(res))

    if a.baseline_pdf:
        ok, rep = content_regression(Path(a.baseline_pdf), Path(a.pdf))
        print(("CONTENT OK: " if ok else "CONTENT FAIL: ") + rep)
        if not ok:
            return 2
        if a.check_geometry:
            ok2, rep2 = geometry_regression(Path(a.baseline_pdf), Path(a.pdf),
                                            tol_pt=a.geometry_tol)
            print(("GEOMETRY OK: " if ok2 else "GEOMETRY FAIL: ") + rep2)
            if not ok2:
                return 2
    return 0 if all(r.ok for r in res) else 1


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="texopt")
    sub = p.add_subparsers(dest="cmd", required=True)

    o = sub.add_parser("optimise")
    o.add_argument("input")
    o.add_argument("-o", "--output", required=True)
    o.add_argument("--start-page", type=int, default=1)
    o.add_argument("--registry")
    o.add_argument("--report")
    o.add_argument("--diff")
    o.add_argument("--no-anchor", action="store_true")
    o.add_argument("--no-preamble", action="store_true")
    o.add_argument("--force-columns", default="")
    o.add_argument("--detect-pattern", action="append")
    o.add_argument("--no-llm", action="store_true",
                   help="skip the model; names become positional (r01c02)")
    o.add_argument("--llm-model", default=None)
    o.add_argument("--name-cache", default=".texopt-names.json",
                   help="persistent name cache; keeps field IDs stable across runs")
    o.add_argument("--widths-log", help="log of an instrumented compile (optional; "
                                        "the probe is run automatically when needed)")
    o.add_argument("--no-probe", dest="probe", action="store_false",
                   help="do not run a probe compile; closed-form tables still convert")
    o.add_argument("--probe-engine", default="xelatex")
    o.add_argument("--probe-dir", default=".texopt-probe")
    o.add_argument("--allow-opaque", action="store_true",
                   help="escape hatch: leave unconvertible tables in place instead of "
                        "failing (their cells will NOT be locatable)")
    o.set_defaults(func=cmd_optimise)

    au = sub.add_parser("audit")
    au.add_argument("input")
    au.set_defaults(func=cmd_audit)

    pr = sub.add_parser("probe")
    pr.add_argument("input")
    pr.add_argument("-o", "--output", required=True)
    pr.set_defaults(func=cmd_probe)

    v = sub.add_parser("verify")
    v.add_argument("tex")
    v.add_argument("pdf")
    v.add_argument("--registry")
    v.add_argument("--baseline-pdf")
    v.add_argument("--check-geometry", action="store_true")
    v.add_argument("--geometry-tol", type=float, default=0.05,
                   help="pt; tight by default because the conversion is "
                        "supposed to reproduce the layout exactly")
    v.set_defaults(func=cmd_verify)

    a = p.parse_args(argv)
    if getattr(a, "llm_model", None) is None and hasattr(a, "llm_model"):
        from .llm import DEFAULT_MODEL
        a.llm_model = DEFAULT_MODEL
    return a.func(a)


if __name__ == "__main__":
    raise SystemExit(main())
