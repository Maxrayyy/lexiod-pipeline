"""
Interface 1 backend: turn an uploaded PDF into a lexoid invocation, and resume it.

Security note (important): the command is built as an **argv list**. Never build the
docker command by string concatenation -- a filename like `a.pdf; rm -rf /` would then
be executed. `preview()` exists only to show a copy-pasteable line and uses shlex.quote.
"""

from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import time
from dataclasses import dataclass, asdict, field
from pathlib import Path, PurePosixPath
from typing import Dict, List, Optional, Tuple

# --------------------------------------------------------------------------- #
# job model
# --------------------------------------------------------------------------- #

SAFE_NAME = re.compile(r"[^A-Za-z0-9._\u4e00-\u9fff-]+")


@dataclass
class LexoidJob:
    job_id: str
    host_workdir: str          # host dir bind-mounted into the container
    input_name: str            # file name inside host_workdir
    output_name: str
    model: str = "gpt-5.6-luna"
    start_page: int = 1
    service: str = "lexoid"
    mode: str = "latex"
    container_mount: str = "/data"
    compose_file: Optional[str] = None
    extra_args: List[str] = field(default_factory=list)
    # runtime state
    status: str = "created"    # created|running|interrupted|done|failed
    last_complete_page: Optional[int] = None
    attempts: List[Dict] = field(default_factory=list)

    # ---- paths ----------------------------------------------------------- #
    @property
    def host_input(self) -> Path:
        return Path(self.host_workdir) / self.input_name

    @property
    def host_output(self) -> Path:
        return Path(self.host_workdir) / self.output_name

    def in_container(self, name: str) -> str:
        return str(PurePosixPath(self.container_mount) / name)

    # ---- command --------------------------------------------------------- #
    def argv(self, start_page: Optional[int] = None,
             output_name: Optional[str] = None) -> List[str]:
        sp = self.start_page if start_page is None else start_page
        out = output_name or self.output_name
        cmd = ["docker", "compose"]
        if self.compose_file:
            cmd += ["-f", self.compose_file]
        cmd += [
            "run", "--rm", "-T",                     # -T: no TTY -> safe under a web server
            "-v", f"{Path(self.host_workdir).resolve()}:{self.container_mount}",
            self.service, self.mode,
            "-i", self.in_container(self.input_name),
            "-o", self.in_container(out),
            "--model", self.model,
        ]
        if sp and sp > 1:
            cmd += ["--start-page", str(sp)]
        cmd += list(self.extra_args)
        return cmd

    def preview(self, **kw) -> str:
        """Human-readable, copy-pasteable. NOT used for execution."""
        return " \\\n  ".join(_chunk(self.argv(**kw)))

    # ---- persistence ------------------------------------------------------ #
    def save(self, state_dir: Path) -> Path:
        p = Path(state_dir) / f"{self.job_id}.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), "utf-8")
        os.replace(tmp, p)          # atomic; survives a crash mid-write
        return p

    @classmethod
    def load(cls, state_dir: Path, job_id: str) -> "LexoidJob":
        data = json.loads((Path(state_dir) / f"{job_id}.json").read_text("utf-8"))
        return cls(**data)


def _chunk(parts: List[str]) -> List[str]:
    """Group argv into readable flag/value pairs for the preview string."""
    out, i = [], 0
    while i < len(parts) and not parts[i].startswith("-"):
        i += 1
    if i:
        out.append(" ".join(shlex.quote(x) for x in parts[:i]))
    while i < len(parts):
        p = parts[i]
        if p.startswith("-") and i + 1 < len(parts) and not parts[i + 1].startswith("-"):
            out.append(f"{shlex.quote(p)} {shlex.quote(parts[i + 1])}")
            i += 2
        else:
            out.append(shlex.quote(p))
            i += 1
    return out


def new_job(host_workdir: str, input_name: str, model: str = "gpt-5.6-luna",
            start_page: int = 1, output_name: Optional[str] = None,
            **kw) -> LexoidJob:
    stem = Path(input_name).stem
    jid = f"{SAFE_NAME.sub('_', stem)}-{int(time.time())}"
    return LexoidJob(
        job_id=jid, host_workdir=host_workdir, input_name=input_name,
        output_name=output_name or f"{stem}.tex", model=model,
        start_page=start_page, **kw)


# --------------------------------------------------------------------------- #
# resume
# --------------------------------------------------------------------------- #

#: ASSUMPTION -- must be aligned with the real lexoid page marker. See texopt.fields.
PAGE_MARKER = re.compile(r"^\s*%+\s*(?:---+\s*)?page[\s_-]*(\d+)", re.I | re.M)


def scan_pages(tex_path: Path) -> List[Tuple[int, int]]:
    """Return [(page_no, char_offset)] for every page marker found."""
    if not Path(tex_path).exists():
        return []
    text = Path(tex_path).read_text("utf-8", errors="replace")
    return [(int(m.group(1)), m.start()) for m in PAGE_MARKER.finditer(text)]


def truncate_to_last_complete_page(tex_path: Path,
                                   backup: bool = True) -> Optional[int]:
    """
    An interrupted run almost always leaves a HALF-WRITTEN last page. Cut it off and
    report the last page that is known-complete, so the resume run re-does exactly one
    page rather than producing a corrupt seam.

    Returns the page number to pass as --start-page, or None if nothing usable.
    """
    marks = scan_pages(tex_path)
    if len(marks) < 2:
        return None
    p = Path(tex_path)
    text = p.read_text("utf-8", errors="replace")
    last_page, last_off = marks[-1]
    if backup:
        p.with_suffix(p.suffix + f".partial-{int(time.time())}").write_text(text, "utf-8")
    p.write_text(text[:last_off], "utf-8")
    return last_page


def resume_argv(job: LexoidJob, shard_dir: Optional[Path] = None) -> Tuple[List[str], int]:
    """
    Build the resume command. The continuation is written to a SEPARATE shard file and
    concatenated afterwards -- lexoid overwrites `-o`, so resuming in place would
    destroy the pages already converted.
    """
    resume_page = truncate_to_last_complete_page(job.host_output)
    if resume_page is None:
        return job.argv(start_page=job.start_page), job.start_page
    shard = f"{Path(job.output_name).stem}.part{resume_page:04d}.tex"
    if shard_dir:
        shard = str(PurePosixPath(shard_dir.name) / shard)
    job.last_complete_page = resume_page - 1
    return job.argv(start_page=resume_page, output_name=shard), resume_page


def merge_shards(base: Path, shards: List[Path], out: Path) -> None:
    """Concatenate base + shards in page order, dropping duplicated page blocks."""
    seen: set[int] = set()
    chunks: List[str] = []
    for f in [base, *shards]:
        if not Path(f).exists():
            continue
        text = Path(f).read_text("utf-8", errors="replace")
        marks = [(int(m.group(1)), m.start()) for m in PAGE_MARKER.finditer(text)]
        if not marks:
            chunks.append(text)
            continue
        if marks[0][1] > 0 and not chunks:
            chunks.append(text[:marks[0][1]])          # preamble of the base file
        for idx, (page, off) in enumerate(marks):
            end = marks[idx + 1][1] if idx + 1 < len(marks) else len(text)
            if page in seen:
                continue
            seen.add(page)
            chunks.append(text[off:end])
    Path(out).write_text("".join(chunks), "utf-8")


# --------------------------------------------------------------------------- #
# execution
# --------------------------------------------------------------------------- #

def run(job: LexoidJob, argv: List[str], log_path: Path,
        timeout: Optional[int] = None) -> int:
    Path(log_path).parent.mkdir(parents=True, exist_ok=True)
    started = time.time()
    with open(log_path, "ab") as log:
        log.write(f"\n$ {' '.join(shlex.quote(a) for a in argv)}\n".encode())
        log.flush()
        proc = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT)
        try:
            rc = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            rc = 124
    job.attempts.append({"argv": argv, "rc": rc,
                         "seconds": round(time.time() - started, 1),
                         "at": time.strftime("%Y-%m-%dT%H:%M:%S")})
    job.status = "done" if rc == 0 else ("interrupted" if rc in (124, 130, 137) else "failed")
    return rc
