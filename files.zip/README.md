# lexoid → tex 优化 → pdf

## 根因

`tabularx` / `tabulary` / `tabu` / `longtabu` / `xltabular` 把环境体吸收成 token list
反复重放来试算 X 列宽度。重放的 token **不再携带原始文件行号**，SyncTeX 只能把整张表
归到重放点。这也是 `\verb` 在 `tabularx` 里失效的同一个机制。

判据：**`\verb` 用不了的表格环境，SyncTeX 就看不到它的 cell。**

| 环境 | body 重放 | 拆 cell 换行有效？ |
|---|---|---|
| `tabular` `tabular*` `array` | 否 | ✅ |
| `longtable` `supertabular` | 否 | ✅ |
| `tabularx` `tabulary` | **是** | ❌ 必须先转换 |
| `tabu` `longtabu` `xltabular` | **是** | ❌ 必须先转换 |

## 格式保留：不变量清单

tabularx → tabular 的每一条语义差异都单独处理，不靠"应该一样"：

| # | 差异 | 处理 |
|---|---|---|
| 1 | X 列本质是 `p{w}`（`\hsize` + `\@arrayparboxrestore`），`p{}` 已含同样处理 | 等价，无需动作 |
| 2 | **宽度字面量精度** | 保留 `\the\hsize` 原串（如 `213.39569pt`），**不 float 截断**。TeX 保证该串精确往返回同一 sp 值 |
| 3 | **整除余数**：`\dimexpr(W−overhead)/n` 截断，总宽少 ≤(n−1)sp | 末列补余 → 总宽精确等于 W。系数非均匀时**不补**，因为 tabularx 自己也不填满 |
| 4 | `>{}` `<{}` `\|` `@{}` 装饰 | 原样保留 |
| 5 | `>{\hsize=k\hsize}` 覆盖 | 剥离（`p{w}` 自己设 `\hsize`），否则会被二次缩放 |
| 6 | body 重放 N 次 → 1 次：`\footnote` `\label` `\refstepcounter` `\caption` 等行为变化 | `format_guard()` 扫描并在 stderr + `report.format_risks` 中告警 |
| 7 | `\verb` 转换后可用（之前必然报错） | 记为 info，不告警 |

每张被转换的表上方留一行审计注释，可追溯、可回滚、不参与排版：

```latex
% texopt: was \begin{tabularx}{\textwidth}{|X|X|X|}  [static]
\begin{tabular}{|p{\dimexpr(\textwidth - 6\tabcolsep - 4\arrayrulewidth)/3\relax}|...}
```

**第 6 类是唯一可能真正改变输出的情况**，且改的方向是"变正确"（原来因重放而重复计数）。
必须用 `verify --check-geometry` 确认，默认容差已收紧到 **0.05pt**。

## 硬约束

优化后 **不允许残留任何 opaque 表格环境**。`optimise` 默认 `strict`：
转不掉就 **exit 3 且不产出文件**，绝不静默降级。

### 列宽来源三级阶梯

| 级 | 来源 | 精度 | 适用 |
|---|---|---|---|
| 1 | 探针实测 `\the\hsize` | 精确 | 任意 colspec（含 `X` 与 `l/c/r` 混排） |
| 2 | LaTeX `\dimexpr` 闭式解 | 精确 | 全 flex 列且无 `@{}` / `!{}` |
| 3 | `UnconvertibleTable` 异常 | — | 上面都不成立 → 硬失败 |

级 2 是闭式解不是近似：全 X 时 `w = (W - 2n·\tabcolsep - r·\arrayrulewidth) / n`，
直接写成 `\dimexpr` 交给 LaTeX 求值，**不需要编译探针**。
`>{\hsize=k\hsize}X`（tabularx，等宽基数×k）和 `X[k,align]`（tabu，按权重比例分配）
的语义差异已分别建模。

只有级 1 需要编译；CLI 会**自动**判断哪些表需要并自己跑探针编译，
不再要求你手动做前置步骤。`--no-probe` 可关闭（此时只有级 2 的表能转）。

`--allow-opaque` 是唯一的降级逃生阀，会明确列出哪些表的 cell 无法定位。

## 四步

```bash
# 0) 诊断（可选）：哪些表根本不可能定位
python -m texopt.cli audit 测试01.tex

# 1) 转换 + 拆 cell + field id（探针编译自动进行，需要时才跑）
python -m texopt.cli optimise 测试01.tex -o 测试01.opt.tex \
    --start-page 76 --registry fields.json --report report.json --diff opt.diff
#    exit 3 = 有表转不掉，报告里 opaque_skipped 说明原因
#    手动测量：texopt probe → 编译 → optimise --widths-log

# 2) 编译 + 校验
xelatex -synctex=1 -interaction=nonstopmode 测试01.opt.tex
python -m texopt.cli verify 测试01.opt.tex 测试01.opt.pdf \
    --registry fields.json --baseline-pdf 测试01.orig.pdf --check-geometry
```

`optimise` 若发现仍有 opaque 表未转换，会在 stderr 报 WARNING 并列进
`report.json` 的 `opaque_remaining`。**不会静默假装成功。**

## 校验（已按要求去掉像素级回归）

* `synctex_roundtrip` —— 正向 tex 行→pdf box，取中心反查回来，断言同一行。100% 才算过。
* `content_regression` —— `pdftotext -layout` 逐页文本比对（页数 + 内容）。无需渲染。
* `geometry_regression` —— `pdftotext -bbox` 词框位移，默认容差 0.5pt。
  **只在做过 tabularx→tabular 转换时开**，用来证明测出来的列宽复现了原布局。

## field id 生成

格式：`p<页码>-<表名>-<语义>`，例如 `p076-dimension_inspection_record-outer_diameter_measured`

**表名来源**（按优先级，全部只读 LaTeX，不做 OCR 对照）：
1. 紧邻表格上方、独占一行的 `\textbf{...}` / `\textsc{...}`
2. 同一空隙内任意位置的粗体串
3. `\caption{...}`
4. 最近的 `\section` / `\subsection` / `\paragraph`

向上扫描在**前一张表的 `\end`** 或**任一 sectioning 命令**处停止，避免偷用邻表标题。

**语义来源**：大模型，**按表批量调用**（不是逐 cell）。理由：
* 同表内 field 名必须互不相同 —— 逐 cell 调用时模型看不到兄弟字段，会重复返回 `value`
* 表名与字段名词汇需一致（`inspection_record` 配 `outer_diameter_measured`）
* 成本降一个数量级

模型返回值一律**消毒后**使用：重新 slug、去重加后缀、缺 key 用位置名补、非 JSON 或拒答则整表回退。
整个请求按指纹缓存到 `.texopt-names.json`，**同一文档重跑产出字节一致的 field id**（下游依赖）。

```bash
export ANTHROPIC_API_KEY=...
python -m texopt.cli optimise ... --llm-model claude-sonnet-5
python -m texopt.cli optimise ... --no-llm     # 离线，名字退化为 r01c02
```

`report.json` 的 `naming` 统计 llm/cache/heuristic 各多少张表，
`naming_fallbacks` 列出退化的表名 —— **不会假装成功**。

## 需要你确认
* lexoid 的分页标记格式 → `fields.DEFAULT_PAGE_MARKERS` / `lexoid_job.PAGE_MARKER`
* lexoid 如何标记手写值 → `fields.DetectorConfig.patterns`（或改用 `--force-columns`）
  —— 这是纯 LaTeX 层面的判定，不需要回看原 PDF
* 中文必须 XeLaTeX + ctex/fontspec
